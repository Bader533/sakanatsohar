<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Living;
use App\Models\Room;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LivingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $living = Living::with('images')->get();
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'data' => $living
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $living = Living::where('id', $id)->with(['rooms' => function ($query) {
            $query->get(['kind', 'price', 'totalrooms', 'currentrooms', 'orderrooms', 'image_url']);
        }])->get();
        $living = Living::join('rooms', 'living.id', '=', 'rooms.living_id')
        ->get(['users.*', 'posts.descrption_en']);
        // User::with(['post' => function ($query) {
        //     $query->select('id', 'user_id');
        // }])->get();

        $oneRoom = Room::where('living_id', $id)->with('living')->first(['description_en', 'description_ar']);
        // dd($oneRoom);
        // $living = Living::with('images')->get();
        return response()->json([
            'status' => true,
            'message' => 'Success',
            'description' => $oneRoom,
            'data' => $living
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
