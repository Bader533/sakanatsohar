<?php $__env->startSection('title','create user'); ?>
<?php $__env->startSection('pageName','Add user'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Add New User</h3>
        </div>
        <form action="<?php echo e(route('user.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card-body">

                <div class="row mb-6">
                    <div class="col-lg-12">
                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control datetimepicker-input"
                                    data-target="#reservationdate" required />


                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>email</label>
                                <input type="email" name="email" class="form-control datetimepicker-input"
                                    data-target="#reservationdate" required />
                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>password</label>
                                <input type="password" name="password" class="form-control datetimepicker-input"
                                    data-target="#reservationdate" required />
                            </div>

                        </div>
                        

                        
                        <div class="row">
                            <div class="col-lg-12 fv-row">
                                <label>Image</label>
                                <input type="file" name="image" class="form-control datetimepicker-input"
                                    data-target="#reservationdate" required />
                            </div>
                        </div><br>
                        

                    </div>

                </div>
                <button type="submit" class="btn btn-primary">Add</button>
            </div>

        </form>
    </div>


</div><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
    <?php if(Session::has('message')): ?>
            toastr.options = {
            "closeButton": true,
            "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
            toastr.options = {
            "closeButton": true,
            "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>

            <?php if(Session::has('info')): ?>
            toastr.options = {
            "closeButton": true,
            "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>

            <?php if(Session::has('warning')): ?>
            toastr.options = {
            "closeButton": true,
            "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SakanatSohar\resources\views/dashboard/admin/user/create.blade.php ENDPATH**/ ?>