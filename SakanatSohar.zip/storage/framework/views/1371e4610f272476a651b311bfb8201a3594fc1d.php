

<?php $__env->startComponent('mail::message'); ?>
# Welcome ,<?php echo e($name); ?>


You Have Requested To Reset Your Password .
<?php $__env->startComponent('mail::panel'); ?>
Reset Code is : <?php echo e($code); ?>

<?php echo $__env->renderComponent(); ?>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\wamp64\www\SakanatSohar\resources\views/mail/user-forget-password-email.blade.php ENDPATH**/ ?>