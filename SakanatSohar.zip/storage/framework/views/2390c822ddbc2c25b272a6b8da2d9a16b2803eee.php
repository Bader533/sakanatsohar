<?php $__env->startSection('title', 'update living'); ?>
<?php $__env->startSection('pageName', 'Update Living'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<style>
    #result {
        display: flex;
        gap: 10px;
        padding: 10px 0;
    }

    .thumbnail {
        height: 200px;
    }

    #multimg {
        display: flex;
        gap: 10px;
        padding: 10px 0;
        height: 200px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Add New Living</h3>
        </div>
        <form action="<?php echo e(route('living.update', $living->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-body">

                <div class="row mb-6">
                    <div class="col-lg-12">
                        
                        <div class="row">

                            <div class="col-lg-6 fv-row">
                                <label>Name En</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="name_en" id="name_en" value="<?php echo e($living->name_en); ?>" class="form-control
                                                        datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>
                            </div>

                            <div class="col-lg-6 fv-row">
                                <label>Name Ar</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="name_ar" value="<?php echo e($living->name_ar); ?>"
                                        class="form-control datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>
                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-6 fv-row">
                                <label>Description En</label>
                                <div class="input-group date" id="reservationdatetime" data-target-input="nearest">
                                    <textarea class="form-control" name="description_en"
                                        id="exampleFormControlTextarea1" rows="3"
                                        required><?php echo e($living->description_en); ?></textarea>
                                </div>
                            </div>

                            <div class="col-lg-6 fv-row">
                                <label>Description Ar</label>
                                <div class="input-group date" id="reservationdatetime" data-target-input="nearest">
                                    <textarea class="form-control" name="description_ar"
                                        id="exampleFormControlTextarea1" rows="3"
                                        required><?php echo e($living->description_ar); ?></textarea>
                                </div>
                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-6 fv-row">
                                <label>Address En</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="address_en" value="<?php echo e($living->address_en); ?>"
                                        class="form-control datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>
                            </div>

                            <div class="col-lg-6 fv-row">
                                <label>Address Ar</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="address_ar" value="<?php echo e($living->address_ar); ?>"
                                        class="form-control datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>
                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-4 fv-row">
                                <label>Owner Name En</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="ownername_en" value="<?php echo e($living->ownername_en); ?>"
                                        class="form-control datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>
                            </div>

                            <div class="col-lg-4 fv-row">
                                <label>Owner Name Ar</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="ownername_ar" value="<?php echo e($living->ownername_ar); ?>"
                                        class="form-control datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>
                            </div>
                            <div class="col-lg-4 fv-row">

                                <label>phone</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="text" name="phone" value="<?php echo e($living->phone); ?>"
                                        class="form-control datetimepicker-input" data-target="#reservationdate"
                                        required />
                                </div>

                            </div>



                        </div>
                        

                        
                        <div class="row">
                            <div class="col-lg-6 fv-row">
                                <label>Image</label>
                                <div class="input-group date" id="reservationdate" data-target-input="nearest">
                                    <input type="file" name="image[]" id="files" multiple class="form-control-file"
                                        data-target="#reservationdate" />
                                    <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="form-text text-danger"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        

                        <div id="multimg">

                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(asset('multi/living/' . $image->image_url)); ?>" height="200px;" alt="">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                        <div class="row mb-3">
                            <label for="example-text-input" class="col-sm-2 col-form-label"> </label>
                            <div class="col-sm-10">
                                <output id="result">
                            </div>
                            <button type="submit" class="btn btn-primary">Update</button>

                        </div>

                    </div>
                </div>

        </form>
    </div>

</div><br>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script type="text/javascript">
    document.querySelector("#files").addEventListener("change", (e) => {
            if (window.File && window.FileReader && window.FileList && window.Blob) {
                document.getElementById("multimg").style.display = "none";
                const files = e.target.files;
                const output = document.querySelector("#result");
                output.innerHTML = "";
                for (let i = 0; i <
                    files.length; i++) {
                    if (!files[i].type.match("image")) continue;
                    const picReader = new FileReader();
                    picReader.addEventListener("load", function(event) {
                        const picFile = event.target;
                        const
                            div = document.createElement("div");
                        div.innerHTML = `<img class="thumbnail" src="${picFile.result}"
        title="${picFile.name}" />`;
                        output.appendChild(div);
                    });
                    picReader.readAsDataURL(files[i]);
                }
            } else {
                alert("Your browser does not support File API");
            }
        });

        <?php if(Session::has('message')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SakanatSohar\resources\views/dashboard/admin/living/edit.blade.php ENDPATH**/ ?>