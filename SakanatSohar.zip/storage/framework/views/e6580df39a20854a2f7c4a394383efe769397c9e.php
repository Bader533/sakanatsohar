<?php $__env->startSection('title', 'update room'); ?>
<?php $__env->startSection('pageName', 'Update Room'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<style>
    #result {
        display: flex;
        gap: 10px;
        padding: 10px 0;
    }

    .thumbnail {
        height: 200px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Update Room</h3>
        </div>
        <form action="<?php echo e(route('room.update', $roomdes->id)); ?>" method="POST" id="formedit"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-body">

                <div class="row mb-6">
                    <div class="col-lg-12">
                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>Living</label>
                                <select name="living_id" class="form-control" id="" required>
                                    <?php $__currentLoopData = $living; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $living): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($living->id); ?>" <?php if($living->id == $roomdes->living_id): ?> selected
                                        <?php endif; ?>
                                        value="<?php echo e($living->id); ?>"><?php echo e($living->name_en); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-6 fv-row">
                                <label>Description En</label>
                                <div class="input-group date" id="reservationdatetime" data-target-input="nearest">
                                    <textarea class="form-control" name="description_en" required
                                        id="exampleFormControlTextarea1"
                                        rows="3"><?php echo e($roomdes->description_en); ?></textarea>
                                </div>
                            </div>

                            <div class="col-lg-6 fv-row">
                                <label>Description Ar</label>
                                <div class="input-group date" id="reservationdatetime" data-target-input="nearest">
                                    <textarea class="form-control" name="description_ar" required
                                        id="exampleFormControlTextarea1"
                                        rows="3"><?php echo e($roomdes->description_ar); ?></textarea>
                                </div>
                            </div>

                        </div><br>
                        

                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <table class="table table-bordered" id="dynamicTable">
                                    <tr>
                                        <th>Kind</th>
                                        <th>Room Count</th>
                                        <th>Price</th>
                                        <th>Image</th>
                                    </tr>
                                    <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <select
                                                name="<?php echo e($rooms->kind === 'single room' ? 'single_room' : ($rooms->kind === 'double room' ? 'double_room' : 'triple_room')); ?>"
                                                class="form-control" id="">
                                                <option value="<?php echo e($rooms->kind); ?>"><?php echo e($rooms->kind); ?>

                                                </option>
                                            </select>
                                        </td>

                                        <td><input type="text"
                                                name="<?php echo e($rooms->kind === 'single room' ? 'single_totalrooms' : ($rooms->kind === 'double room' ? 'double_totalrooms' : 'triple_totalrooms')); ?>"
                                                value="<?php echo e($rooms->totalrooms); ?>" class="form-control" />
                                        </td>
                                        <td><input type="text"
                                                name="<?php echo e($rooms->kind === 'single room' ? 'single_price' : ($rooms->kind === 'double room' ? 'double_price' : 'triple_price')); ?>"
                                                value="<?php echo e($rooms->price); ?>" class="form-control" />
                                        </td>
                                        <td><input type="file" id="upload"
                                                onchange="loadFile(event,'<?php echo e($rooms->kind); ?>')"
                                                name="<?php echo e($rooms->kind === 'single room' ? 'single_image' : ($rooms->kind === 'double room' ? 'double_image' : 'triple_image')); ?>"
                                                value="" class="input-group date" /><br>
                                            <img id="image<?php echo e($key); ?>"
                                                src="<?php echo e(asset('multi/rooms/' . $rooms->image_url)); ?>" width="100" />
                                            <img id="output<?php echo e($key); ?>" width="100" />
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if(count($result) != 0): ?>
                                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $results): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <select
                                                name="<?php echo e($results === 'single room' ? 'single_room' : ($results === 'double room' ? 'double_room' : 'triple_totalrooms')); ?>"
                                                class="form-control" id="">
                                                <option value="<?php echo e($results); ?>"><?php echo e($results); ?>

                                                </option>
                                            </select>
                                        </td>

                                        <td><input type="text"
                                                name="<?php echo e($results === 'single room' ? 'single_totalrooms' : ($results === 'double room' ? 'double_totalrooms' : 'triple_totalrooms')); ?>"
                                                value="0" class="form-control" />
                                        </td>
                                        <td><input type="text"
                                                name="<?php echo e($results === 'single room' ? 'single_price' : ($results === 'double room' ? 'double_price' : 'triple_price')); ?>"
                                                value="0" class="form-control" />
                                        </td>
                                        <td><input type="file" id="files"
                                                name="<?php echo e($results === 'single room' ? 'single_image' : ($results === 'double room' ? 'double_image' : 'triple_image')); ?>"
                                                value="" class="input-group date" />
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                </table>
                            </div>

                        </div>
                        


                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Update</button>

            </div>
        </form>
    </div>


</div><br>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script type="text/javascript">
    var loadFile = function(event, name) {
            if (name == 'single room') {
                document.getElementById("image0").style.display = "none";
                var image = document.getElementById('output0');
                image.src = URL.createObjectURL(event.target.files[0]);
            } else if (name == 'double room') {
                document.getElementById("image1").style.display = "none";
                var image = document.getElementById('output1');
                image.src = URL.createObjectURL(event.target.files[0]);
            } else {
                document.getElementById("image2").style.display = "none";
                var image = document.getElementById('output2');
                image.src = URL.createObjectURL(event.target.files[0]);
            }

        };


        <?php if(Session::has('message')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SakanatSohar\resources\views/dashboard/admin/room/edit.blade.php ENDPATH**/ ?>