<?php $__env->startSection('title', 'update user'); ?>
<?php $__env->startSection('pageName', 'Update User'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<style>
    #result {
        display: flex;
        gap: 10px;
        padding: 10px 0;
    }

    .thumbnail {
        height: 200px;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Update User</h3>
        </div>
        <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="card-body">

                <div class="row mb-6">
                    <div class="col-lg-12">
                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>Name</label>
                                <input type="text" name="name" value="<?php echo e($user->name); ?>"
                                    class="form-control datetimepicker-input" data-target="#reservationdate" required />


                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>email</label>
                                <input type="email" name="email" value="<?php echo e($user->email); ?>"
                                    class="form-control datetimepicker-input" data-target="#reservationdate" required />
                            </div>

                        </div>
                        

                        
                        <div class="row">

                            <div class="col-lg-12 fv-row">
                                <label>password</label>
                                <input type="password" name="password" class="form-control datetimepicker-input"
                                    data-target="#reservationdate" />
                            </div>

                        </div>
                        

                        
                        <div class="row">
                            <div class="col-lg-12 fv-row">
                                <label>Image</label>
                                <input type="file" name="image" class="input-group date" id="files"
                                    data-target="#reservationdate" />
                            </div>
                        </div><br>
                        
                        <img id="multimg" src="<?php echo e(asset('multi/' . $user->image_url)); ?>" height="200px;" alt="">
                        <div>


                            <div class="row mb-3">
                                <div class="col-sm-10">
                                    <output id="result" width="200">
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">update</button>

            </div>
        </form>
    </div>


</div><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
    document.querySelector("#files").addEventListener("change", (e) => {
            if (window.File && window.FileReader && window.FileList && window.Blob) {
                document.getElementById("multimg").style.display = "none";
                const files = e.target.files;
                const output = document.querySelector("#result");
                output.innerHTML = "";
                for (let i = 0; i <
                    files.length; i++) {
                    if (!files[i].type.match("image")) continue;
                    const picReader = new FileReader();
                    picReader.addEventListener("load", function(event) {
                        const picFile = event.target;
                        const
                            div = document.createElement("div");
                        div.innerHTML = `<img class="thumbnail" src="${picFile.result}"
        title="${picFile.name}" />`;
                        output.appendChild(div);
                    });
                    picReader.readAsDataURL(files[i]);
                }
            } else {
                alert("Your browser does not support File API");
            }
        });


        <?php if(Session::has('message')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.success("<?php echo e(session('message')); ?>");
        <?php endif; ?>

        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(Session::has('info')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        <?php if(Session::has('warning')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.starter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\SakanatSohar\resources\views/dashboard/admin/user/edit.blade.php ENDPATH**/ ?>